# mypackage
This libary was created as an example for how to publish your own Python package

# how to install
...